# native-todo

This is a react-native todo list. you can read up on the build process on https://dev.to/reenydavidson/building-a-to-do-list-with-react-native-and-styled-components-2148

Tools

1. React-Native
2. Styled-Components
3. Material Icons
